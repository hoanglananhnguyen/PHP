<?php

session_start();
	//process-login.php

	//receive form variables
	$username = $_POST["username"];
	$password = $_POST["password"];

    //check username & pw is correct/not
	//compare submitted the username and password to 
	//the data in the database 
	
	//connect
	$dsn = "mysql:host=localhost;dbname=singhwa_imm2023;charset=utf8mb4";
	$dbusername = "root";
	$dbpassword = "root";

	$pdo = new PDO($dsn, $dbusername, $dbpassword);

	//prepare
	$stmt = $pdo->prepare("SELECT * FROM `user`
	WHERE `user`.`username` = '$username'
	AND `user`.`password` = '$password';
	AND `user`.`role` = '$role';");

	//execute
	$stmt->execute();

	// if u/p correct and role is admin => show select-articles.php
	// else show error


	if($row = $stmt->fetch()){
		//remember this user's logged-in status and their name
		$_SESSION["loggedIn"] = 1;
		$_SESSION["username"] = $row["username"]; // $row[number]
		$_SESSION["password"] = $row["password"]; // $row[number]
		$_SESSION["role"] = $row["role"]; // $row[number]
		
		if ($_SESSION["role"] == "administrator"){
			
			//show select-articles.php
		header("Location: articleApp/admin-select-articles.php");
		} 
		else {
			header("Location: articleApp/user-select-articles.php");
		}
	}

	else{
		//show error 
		header("Location: fail-login.php");
	}
?>
