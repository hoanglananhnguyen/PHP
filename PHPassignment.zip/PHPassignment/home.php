<?php ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
    <link rel="icon" type="image/x-icon" href="image/favicon.ico">
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    
</head>

<body>

    <header>
        <div class="container">
            <div class="main-header">
                <img class="logo" src="image/logo.png" alt="Logo" style="width:60px;height:60px">
                <nav>
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="contact-form.php">Contact</a></li>
                        <li><a href="login-form.php">Login</a></li>
                        <li><a href="signup-form.php">Sign up</a></li>

                    </ul>
                </nav>
            </div>
        </div>  
    </header>   

        <div class="content" id="main">
            <div class="container">
                <section class="welcome">
                    <h1>Welcome to Imm News Network</h1>
                    <p>Are you looking for a lawyer who understands Canadian and American immigration issues? Imm News Network has years of immigration experience and can offer you local representation while helping you understand the important details of your case. We know that you may be feeling overwhelmed by the immigration process, and we'll do everything possible to alleviate some of your burdens.
                    </p>
                </section>
            </div>
    
            <div class="articles">
                <section class="featured">
                    <div class="heading-featured">
                        <h2><a href="articles/feature.php">Featured Article</a></h2>
                    </div>
    
                    <div class="featured-post">
                        <h3>The Top Trending Jobs in Canada 2022</h3>
                        <div class="featured-author">Author: Stephany</div>
                        <img src="image/The-Top-Trending-Jobs-in-Canada-2022-compressed.jpeg" 
                            width="400px" height="250px" 
                            alt="">
                        <p> 
                            Canada is planning to offer citizenship to 300,000 immigrants in the year 2022-2023. A recent memo by IRCC outlines targets for the number of new citizens the country is planning to welcome in the fiscal year 2022-2023... 
                        </p>
                        <a href="articles/feature.php">Read more</a>
                    </div>
                     
                </section>
            
             <div class="container-category">  
                <section class="category" id="industry">
                    <div class="heading-category">
                        <h2><a href="articles/industry.php">Industry</a></h2>
                    </div>
        
                    <div class="posts">
                        <div class="post">   
                            <h3>This Fiscal Year, IRCC Plans to Grant Citizenship to 300,000 People</h3>
                            <div class="industry-author">Author: Rosary</div>
                            <img src="image/This-Fiscal-Year-IRCC-Plans-to-Grant-Citizenship-to-300000-People-ImmigCanada.jpeg" 
                            width="400px" height="250px" 
                            alt="">
                            <p> 
                            Canada is planning to offer citizenship to 300,000 immigrants in the year 2022-2023.A recent memo by IRCC outlines targets for the number of new citizens the country is planning to welcome in the fiscal year 2022-2023...
                            </p>
                            <a href="articles/industry.php">Read more</a>
                        </div>
                        
                        <div class="post">
                            <h3>Canada Still has More Vacancies than Jobs</h3>
                            <div class="industry-author">Author: William</div>
                            <img src="image/Canada-Still-has-More-Vacancies-than-Jobs-ImmigCanada.jpeg" 
                            width="400px" height="250px" 
                            alt="">
                            <p> 
                                Recently, Canada’s employment rate has been falling, with many of their job vacancies not being filled. In addition, Canada’s monthly report on pay and employment has revealed that the number of employees receiving pay or benefits from their employer has decreased for the first time since last May...
                            </p>
                            <a href="articles/industry.php">Read more</a>
                        </div>
                    </div>   
                </section>
    
                <section class="category" id="technical">
                    <div class="heading-category">
                        <h2><a href="articles/technical.php">Technical</a></h2>
                    </div>
    
                    <div class="posts">
                        <div class="post">
                            <h3>International Student Recruitment and Retention is a Priority for Canada</h3>
                            <div class="technical-author">Author: Brown Black</div>
                            <img src="image/The-Express-Entry-CRS-score-slips-to-496-in-an-All-Program-Draw-IMC.jpeg" 
                            width="400px" height="250px" 
                            alt="">
                            <p> 
                            Immigration Refugees and Citizenship Canada (IRCC) has responded to the Standing Committee on Citizenship and Immigration (CIMM) of the Canadian House of Commons on measures needed to attract, aid, and protect international students... 
                            </p>
                            <a href="articles/technical.php">Read more</a>  
                        </div>
                    
                        <div class="post">
                            <h3>Can You Apply for Multiple Canadian Immigration Programs Together?</h3>
                            <div class="technical-author">Author: Dan Smith </div>
                            <img src="image/Can-you-Apply-for-Multiple-Canadian-Immigration-Programs-Together-CIN.jpeg" 
                            width="400px" height="250px" 
                            alt="">
                            <p> 
                            Canada offers more than 100 economic class immigration programs to choose from, it is likely to qualify for more than one Canadian immigration program... </p>
                            <a href="articles/technical.php">Read more</a> 
                        </div>
                    </div>
                    
                </section>
    
                <section class="category" id="career">
                    <div class="heading-category">
                        <h2><a href="articles/career.php">Career</a></h2>
                    </div>
                  
                    <div class="posts">
                        <div class="post">
                            <h3>Canada Strengthens Protections for Temporary Foreign Workers</h3>
                            <div class="career-author">Author: Peter Pan</div>
                            <img src="image/Canada-Strengthens-Protections-for-Temporary-Foreign-Workers-ImmigCanada.jpg" 
                            width="400px" height="250px" 
                            alt="">
                            <p> 
                            Employment and Social Development Canada (ESDC) with Immigration, Refugees and Citizenship Canada (IRCC) has announced reforms to the Immigration and Refugee Protection Regulations regarding Temporary Foreign Workers (TFWs)... 
                            </p>
                            <a href="articles/career.php">Read more</a> 
                        </div> 
    
                        
                        <div class="post">
                            <h3>International Students Will Be Allowed to Work Off-Campus For More than 20 Hours A Week in Canada</h3>
                            <div class="career-author">Author: Will Smith</div>
                            <img src="image/International-Students-will-be-allowed-to-work-off-campus-for-more-than-20-hours-a-week-in-Canada-compressed.jpeg" 
                                width="400px" height="250px" 
                                alt="">
                            <p> 
                                Between November 15, 2022, and December 31, 2022, international students who are studying in Canada and have off-campus authorization on their study permit will be permitted to work 20 hours a week... 
                            </p>
                            <a href="articles/career.php">Read more</a>
                        </div>
                    </div>
                    
                </section>
            </div> 
            
                <iframe 
                width="320" 
                height="240"
                source src="https://www.youtube.com/embed/YsUzBxp_1cI"></iframe>
            
                <div>
                    <button onclick="toggleHighContrast()">hi-constrast mode</button>
                </div>

            </div>

       
    <footer id="banner">
        <p id="cookies">Accept cookies?</p>
        <div id="output"></div>
        <a id="link" href="#"></a>
    
    </footer> 
    
    <script src="main.js"></script>
     
</body>
</html>