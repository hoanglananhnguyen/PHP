 <?php ?>
 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
    <link rel="icon" type="image/x-icon" href="image/favicon.ico">
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    

<!--PHP ---- -->

<?php
//process-contact-form.php
//receive form variables

$name = $_POST["name"];
$email = $_POST["email"];
$categoryInterest = join(",", $_POST["categoryInterest"]);
$role = $_POST["role"];


// process variables
//insert data into database table
//connect

$dsn = "mysql:host=localhost;dbname=singhwa_imm2023;charset=utf8mb4";
$dbusername = "root";
$dbpassword = "root";

$pdo = new PDO($dsn, $dbusername, $dbpassword);

//prepare
$stmt = $pdo->prepare("INSERT INTO `Contact-Form` 
(`contactId`, `name`, `email`, `categoryInterest`, `role`) 
VALUES 
(NULL, '$name', '$email', '$categoryInterest', '$role');");

if($stmt->execute() == true){
    ?><p>Thank you<p><?php
}else{
    ?> <p>Please submit again<p>
        <a href="contact-form.php">Back to contact form</a>
        <?php
}
?>

</head>

<body>
</body>
</html>

