<?php ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>home</title>
        <link rel="icon" type="image/x-icon" href="image/favicon.ico">
        <link rel="stylesheet" href="../style.css">
        <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
	
		<?php
        session_start();
	
	//connect
		$dsn = "mysql:host=localhost;dbname=singhwa_imm2023;charset=utf8mb4";
		$dbusername = "root";
		$dbpassword = "root";

		$pdo = new PDO($dsn, $dbusername, $dbpassword);

	//prepare
		$stmt = $pdo->prepare("SELECT * FROM `article`");
	
	//execute
		$stmt->execute();

	//display/process results
		while ($row = $stmt->fetch(){
            ?><p><?=$row["articleId"];?></p>
            <p><?=$row["articleName"];?></p>
            <p><?=$row["articleBody"];?></p>
            <p><?=$row["image"];?></p>      
			<img src="uploads/<?= $row["image"]; ?>"><?php
			 }
		?>
	
	</head>

<body>
    <header>
       
    </header>      

    
    <script src="main.js"></script>

	

</body>
</html>


