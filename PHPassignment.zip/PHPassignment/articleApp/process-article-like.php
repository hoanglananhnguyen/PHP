<?php
//process-article-like.php
session_start();

$articleId = $_GET['articleId'];
// $userId = $_POST['userId'];
// $like = $_GET['like'];

//connect
$dsn = "mysql:host=localhost;dbname=singhwa_imm2023;charset=utf8mb4";
$dbusername = "root";
$dbpassword = "root";

$pdo = new PDO($dsn, $dbusername, $dbpassword);

//prepare

$stmt = $pdo->prepare("SELECT * FROM `Article-User`
WHERE `Article-User`.`articleId` = '$articleId'
-- AND `Article-User`.`userId = '$userId';
-- AND `Article-User`.`like` = '$like';");

//execute
$stmt->execute();

while ($row = $stmt->fetch()){
    $_SESSION["userId"] = $row["userId"];
    if(isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] == 1);
        if (isset($_SESSION['like'] == true {
            header("Location: articleApp/insert-record.php");
    } else {

    }
}

//insert record into the user-article table
