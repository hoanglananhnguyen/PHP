<?php ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>home</title>
        <link rel="icon" type="image/x-icon" href="image/favicon.ico">
        <link rel="stylesheet" href="../style.css">
        <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
        
</head>

<body>
    <header>
        <div class="container">
            <div class="main-header">
                
                <img class="logo" src="../image/logo.png" alt="Logo" style="width:60px;height:60px">
                <nav>
                    <ul>
                        <li><a href="../home.php">Home</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="../contact-form.php">Contact</a></li>
						<li><a href="logout.php">Logout</a></li>
						<li><a href="login-form.php">Back</a></li>
						<li><a href="article-form.php">Add a new article</a></li>
                    </ul>
                </nav>
            </div>
        </div>  
    </header>
    
<!--------------body -------------->

<?php
// delete-article-confirmation.php

//receive the variables that this script needs to run
$articleId = $_GET["articleId"];

//get data for the article that we want to delete

//connect
$dsn = "mysql:host=localhost;dbname=singhwa_imm2023;charset=utf8mb4";
$dbusername = "root";
$dbpassword = "root";

$pdo = new PDO($dsn, $dbusername, $dbpassword);

//prepare
$stmt = $pdo->prepare("SELECT * 
    FROM `article` 
    WHERE `articleId` = $articleId");

$stmt->execute();
$row = $stmt->fetch();

//show confirmation screen

?>  
    <div class="content">
    <h1>Are you sure you want to delete this article?</h1>
    <p>Article Id: <?= $row["articleId"] ?> </p>
    <p>Article Name: <?= $row["articleName"] ?> </p>
    <p>Image: <?= $row["image"] ?> </p>
    <p>Article Body <?= $row["articleBody"] ?> </p>

    <form action="delete-article.php" method="POST">
    <input type="hidden" name="articleId" value="<?= $row["articleId"] ?> ">
    <button><a href="admin-select-articles.php">NO</a></button>
    <input type="submit" value="CONFIRM DELETE">

    </form>
    </div>
    <script src="main.js"></script>

</body>
</html>