<?php
//process-add-article.php

 $articleName = $_POST['articleName'];
 $articleBody = $_POST['articleBody'];

//upload the file

$uploaddir = "uploads/";
$uploadfile = $uploaddir . basename($_FILES["articleImage"]["name"]);

$imageName = $_FILES["articleImage"]["name"];

if (move_uploaded_file($_FILES["articleImage"]["tmp_name"], $uploadfile)) {
    echo "File is valid, and was successfully uploaded.\n";
} else {
    echo "Possible file upload attack!\n";
}

//insert data to the database
//connect
	$dsn = "mysql:host=localhost;dbname=singhwa_imm2023;charset=utf8mb4";
	$dbusername = "root";
	$dbpassword = "root";

	$pdo = new PDO($dsn, $dbusername, $dbpassword);

	//prepare
	$stmt = $pdo->prepare("INSERT INTO `article` 
		(`articleId`, `articleName`, `image`, `articleBody`) 
		VALUES (NULL, '$articleName', '$imageName', '$articleBody');");

	if($stmt->execute() == true){
		?><p>Your record was sucessfully added<p><?php
	}else{
		?> <p>Your data could not be inserted<p><?php
	}

?>