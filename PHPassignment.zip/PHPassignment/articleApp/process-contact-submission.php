<?php ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>home</title>
        <link rel="icon" type="image/x-icon" href="image/favicon.ico">
        <link rel="stylesheet" href="../style.css">
        <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
        
    </head>
<body>
    <header>
        <div class="container">
            <div class="main-header">
                
                <img class="logo" src="../image/logo.png" alt="Logo" style="width:60px;height:60px">
                <nav>
                    <ul>
                        <li><a href="../home.php">Home</a></li>
                        <li><a href="select-about-page.php">About</a></li>
                        <li><a href="process-contact-submission.php">Contact</a></li>
						<li><a href="../logout.php">Logout</a></li>
						<li><a href="article-form.php">Add a new article</a></li>
                    </ul>
                </nav>
            </div>
        </div>  
    </header>  

<?php
session_start();
//process-contact-form-submission.php
//connect
	$dsn = "mysql:host=localhost;dbname=singhwa_imm2023;charset=utf8mb4";	
	$dbusername = "root";
	$dbpassword = "root";

	$pdo = new PDO($dsn, $dbusername, $dbpassword);

	//prepare
	$stmt = $pdo->prepare("SELECT * FROM `Contact-Form`");
	
	//execute
	$stmt->execute();
    ?><h1>Contact submission</h1><?php
	while($row = $stmt->fetch()) {
	?>
	<div class="content">
		<p>Contact Id: <?= $row["contactId"]; ?> </p>
		<p>Name: <?= $row["name"]; ?> </p>
		<p>Email: <?= $row["email"]; ?> </p>
		<p>Category Interest: <?= $row["categoryInterest"]; ?> </p>
		<p>Role: <?= $row["role"]; ?> </p>
	</div>
	<?php
	}

?>