<?php //update-article-form.php ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
    <link rel="icon" type="image/x-icon" href="image/favicon.ico">
    <link rel="stylesheet" href="../style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">

</head>


<body>
    <header>
        <div class="container">
            <div class="main-header">
                
                <img class="logo" src="../image/logo.png" alt="Logo" style="width:60px;height:60px">
                <nav>
                    <ul>
                        <li><a href="../home.php">Home</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="contact-submission.php">Contact</a></li>
						<li><a href="article-form.php">Add a new article</a></li>
                        <li><a href="delete-article.php">Delete</a></li>
                        <li><a href="admin-select-articles.php">Articles</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </nav>
            </div>
        </div>  
    </header>

    <?php
//RECEIVE articleId
$articleId = $_GET["articleId"];

//connect
$dsn = "mysql:host=localhost;dbname=singhwa_imm2023;charset=utf8mb4";
$dbusername = "root";
$dbpassword = "root";

$pdo = new PDO($dsn, $dbusername, $dbpassword);

//prepare
$stmt = $pdo->prepare("SELECT * 
    FROM `article` 
    WHERE `articleId` = $articleId");

$stmt->execute();
$row = $stmt->fetch();

//allow admin to edit article
?>
<div class="content">
<h1>Update this article?</h1>

<form action="process-update-article.php" method="POST" enctype="multipart/form-data">
<p>Article name:<input type="text" name="articleName" value="<?= $row["articleName"] ?>"></p>
<div>Article body:<textarea name="articleBody"><?= $row["articleBody"] ?></textarea></div>
<input type="file" name="articleImage"><br> 
<img src="<?= $row["image"] ?>"><br>

<input type="hidden" name="articleId" value="<?= $row["articleId"] ?> ">
<input type="submit" value="Save changes">
<button><a href="admin-select-articles.php">Cancel</a></button>

</form>
</div>
    
</body>
<html>