<?php ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
    <link rel="icon" type="image/x-icon" href="image/favicon.ico">
    <link rel="stylesheet" href="../style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">

    <?php
    //process-update-article.php
    //receive variables needed by this script
    $articleName = $_POST['articleName'];
    $articleBody = $_POST['articleBody'];
    $articleId = $_POST['articleId'];

    $uploaddir = "uploads/";
    $uploadfile = $uploaddir . basename($_FILES["articleImage"]["name"]);

    $imageName = $_FILES["articleImage"]["name"];
    if (move_uploaded_file($_FILES["articleImage"]["tmp_name"], $uploadfile)) {
        echo "File is valid, and was successfully uploaded.\n";
    } else {
    echo "Possible file upload attack!\n";
    }

    //update specified record in table
    //connect
    $dsn = "mysql:host=localhost;dbname=singhwa_imm2023;charset=utf8mb4";
    $dbusername = "root";
    $dbpassword = "root";

    $pdo = new PDO($dsn, $dbusername, $dbpassword);

    //prepare
    $stmt = $pdo->prepare("UPDATE `article` 
        SET `articleName` = '$articleName', 
        `image` = '$imageName', 
        `articleBody` = '$articleBody' 
        WHERE `article`.`articleId` = $articleId;");

        if ($stmt->execute() == true)
        { ?><p>Your article was sucessfully updated<p><?php
        }else{
            ?> <p>Your article could not be updated<p><?php
        }
    ?>
  
</head>
<body>
<a href="admin-select-articles.php">Back to articles</a>


</body>
</html>


