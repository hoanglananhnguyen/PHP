<?php ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
    <link rel="icon" type="image/x-icon" href="image/favicon.ico">
    <link rel="stylesheet" href="../style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">

<?php
//process-update-about-page.php
//receive variables needed by this script
$header = $_POST['header'];
$body = $_POST['body'];
$id = $_POST['id'];

//update specified record in table
//connect
$dsn = "mysql:host=localhost;dbname=singhwa_imm2023;charset=utf8mb4";
$dbusername = "root";
$dbpassword = "root";

$pdo = new PDO($dsn, $dbusername, $dbpassword);

//prepare
$stmt = $pdo->prepare("UPDATE `About` 
    SET `header` = '$header', 
    `body` = '$body' 
    WHERE `About`.`id` = $id;");

    if ($stmt->execute() == true)
    { ?><p>Your About Page was sucessfully updated<p><?php
    }else{
        ?> <p>Your About Page could not be updated<p><?php
    }
?>
<a href="select-about-page.php">Back to About Page</a>

