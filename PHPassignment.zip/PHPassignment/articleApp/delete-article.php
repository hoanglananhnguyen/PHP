<?php

//delete-article.php

//receive the articleId via POST
$articleId = $_POST["articleId"];

//delete a record using the articleId

//connect
$dsn = "mysql:host=localhost;dbname=singhwa_imm2023;charset=utf8mb4";
$dbusername = "root";
$dbpassword = "root";

$pdo = new PDO($dsn, $dbusername, $dbpassword);

//prepare
$stmt = $pdo->prepare("DELETE 
    FROM `article` 
    WHERE `article`.`articleId` = $articleId");

if($stmt->execute() == true){
    ?><p>Your article was sucessfully deleted<p><?php
}else{
    ?> <p>Your data could not be deleted<p><?php
}
?>
<a href="admin-select-articles.php">Back to articles</a>
