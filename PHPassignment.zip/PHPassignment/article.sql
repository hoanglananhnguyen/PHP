-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Dec 04, 2022 at 12:43 AM
-- Server version: 5.7.34
-- PHP Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `singhwa_imm2023`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `articleId` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `articleName` varchar(300) NOT NULL,
  `author` varchar(50) NOT NULL,
  `image` varchar(300) NOT NULL,
  `articleBody` text NOT NULL,
  `feature` int(1) NOT NULL,
  `total likes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`articleId`, `category`, `articleName`, `author`, `image`, `articleBody`, `feature`, `total likes`) VALUES
(22, 'technical', 'Can You Apply for Multiple Canadian Immigration Programs Together?', 'Dan Smith', 'This-Fiscal-Year-IRCC-Plans-to-Grant-Citizenship-to-300000-People-ImmigCanada.jpeg', 'Canada offers more than 100 economic class immigration programs to choose from, it is likely to qualify for more than one Canadian immigration program. Thus, it also raises the question of whether you can apply for more than one program at the same time or not. Possibly you can qualify for Express Entry, however, do not necessarily wish to cross your fingers for Invitation to Apply (ITA), as that base Provincial Nominee Program (PNP) looks more interesting- even if it’s a long process. The question is whether you can apply for both or not.\r\n\r\n Immigration, Refugees, and Citizenship Canada (IRCC) suggest one may go ahead with two applications at once, however, they have to withdraw one before a decision can be made on the other and one must also know that they will not receive a refund on any processing fees paid. In a case, where the candidate has applied second application while an earlier application is in litigation, both of them will be processed through their respective processes until the final decision is made on one of the applications.\r\n\r\nOne can have only one Express Entry Profile\r\n\r\n Canadian immigration regulations do not permit one to have more than one profile at a time. The IRCC clearly states that having more than one profile will not offer a better chance of being shortlisted, nor permit one to be invited under another program. One may, include their common-law partner or spouse on their Express Entry application. Every application that goes through Express Entry has a principal applicant (PA), who is evaluated through the Comprehensive Ranking System and gets a score. The principal applicant (PA) is permitted to add the spouse and dependent children to the application.\r\n\r\nWhile applying as a couple, only one of the partners can be the PA. The couple can select which partner can be the PA as long as both partners stand eligible for at least one Express Entry-managed program. This rule is essential as one of the partners will definitely have a higher CRS score than the other.', 1, 0),
(23, 'career', 'Canada Strengthens Protections for Temporary Foreign Workers', 'Peter Pan', 'Canada-Strengthens-Protections-for-Temporary-Foreign-Workers-ImmigCanada.jpg', 'Employment and Social Development Canada (ESDC) with Immigration, Refugees and Citizenship Canada (IRCC) has announced reforms to the Immigration and Refugee Protection Regulations regarding Temporary Foreign Workers (TFWs). There are 13 reforms designed to support protections for TFWs and improve the Temporary Foreign Workers Program (TFWP).\r\n\r\nTFWs possess similar rights as Canadian citizens or permanent residents. This concludes that employers are legally obligated to offer a safe working atmosphere that is free from harassment and reprisals. Furthermore, if an employer refuses to pay overtime to an employee as stipulated in the employment agreement, it is illegal. Employees make sure to have a signed copy of this agreement before they first start the job.', 0, 0),
(24, 'industry', 'This Fiscal Year, IRCC Plans to Grant Citizenship to 300,000 People', 'Rosary', 'This-Fiscal-Year-IRCC-Plans-to-Grant-Citizenship-to-300000-People-ImmigCanada.jpeg', 'Canada is planning to offer citizenship to 300,000 immigrants in the year 2022-2023. A recent memo by IRCC outlines targets for the number of new citizens the country is planning to welcome in the fiscal year 2022-2023. The memo was drafted by the Operations, Planning, and Performance department of IRCC which recommends that it process a total of 285,000 decisions and 300,000 new citizens by March 31, 2023. Upon reviewing an application, a decision is made that either approves, denies, or marks the application as incomplete. A citizenship target means that 300,000 approved applicants must take the oath of citizenship.', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`articleId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `articleId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
