-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Dec 04, 2022 at 12:43 AM
-- Server version: 5.7.34
-- PHP Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `singhwa_imm2023`
--

-- --------------------------------------------------------

--
-- Table structure for table `Contact-Form`
--

CREATE TABLE `Contact-Form` (
  `contactId` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `categoryInterest` varchar(30) NOT NULL,
  `role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Contact-Form`
--

INSERT INTO `Contact-Form` (`contactId`, `name`, `email`, `categoryInterest`, `role`) VALUES
(1, 'Anh', 'hoanglananh.nguyen@gmail.com', 'Industry', 'writer'),
(10, 'nnn', 'n@yahoo.com', 'Industry', 'contributor'),
(11, 'mmm', 'ong@yahoo.com', '', 'writer'),
(12, 'pp', 'ong@yahoo.com', '', 'writer'),
(13, 'Anh nguyen', 'hoanglananh.nguyen@gmail.com', 'Technical', 'writer'),
(17, 'hey', 'hey@gmail.com', 'Technical,Career', 'writer'),
(20, 'lol', 'lol@hotmail.com', 'Technical,Career', 'administrator'),
(21, 'aaa', 'vvv@gg.com', 'Technical', 'writer'),
(22, 'john', 'john@gmail.com', 'Industry,Technical', 'contributor'),
(24, 'sc', 'hoanglananh.nguyen@gmail.com', 'Industry,Technical', 'contributor'),
(25, 'hey', 'hey@gmail.com', 'Industry', 'administrator'),
(52, '', '', '', ''),
(53, '', '', '', ''),
(54, '', '', '', ''),
(55, '', '', '', ''),
(56, '', '', '', ''),
(57, '', '', '', ''),
(58, '', '', '', ''),
(59, '', '', '', ''),
(60, '', '', '', ''),
(61, '', '', '', ''),
(62, '', '', '', ''),
(63, '', '', '', ''),
(64, '', '', '', ''),
(65, '', '', '', ''),
(66, '', '', '', ''),
(67, '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Contact-Form`
--
ALTER TABLE `Contact-Form`
  ADD PRIMARY KEY (`contactId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Contact-Form`
--
ALTER TABLE `Contact-Form`
  MODIFY `contactId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
