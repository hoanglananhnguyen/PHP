<?php
// contact-form.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
    <link rel="icon" type="image/x-icon" href="image/favicon.ico">
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    
</head>

<body>
    <!--------------header -------------->
    <header>
        <div class="container">
            <div class="main-header">
                
                <img class="logo" src="image/logo.png" alt="Logo" style="width:60px;height:60px">
                <nav>
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Contact</a></li>
                    </ul>
                </nav>
            </div>
        </div>  
    </header>   

    
    <div class="page">
        <div class="content">
            <section id="contact">
                <h1>Contact Form</h1>
                    <form action="process-contact-form.php"method="METHOD">
                    <div>
                        Name:<input type="text" id="name" name="name" placeholder="John" required/>
                    </div>
                    <div>
                        Email:<input type="email" id="email" name="email" placeholder="john@gmail.com" required/>
                    </div>
                    
                    <div class="checkbox-container">
                        <label class="info" for="category interests">Category interests:</label><br>
                        <div class="checkbox">
                            <input type="checkbox" name="industry"/>
                            <label for="industry">Industry</label>
                        </div>
                        
                        <div class="checkbox">
                            <input type="checkbox" name="technical"/>
                            <label for="technical">Technical</label>
                        </div>

                        <div class="checkbox">
                            <input type="checkbox" name="career"/>
                            <label for="career">Career</label>
                        </div>
                    </div>

                    <div class="drop">
                    <label  class="info" for="your role">Your role:</label><br>
                        <select name="your role">
                            <option value="1" selected>Writer</option>
                            <option value="2" selected>Contributor</option>
                            <option value="3" selected>Administrator</option>
                        </select>
                    </div>
                    <div class="button">
                    <input type="submit" value="submit">
                    </div>
                </form>
            </section>
        </div>

    </div>
<!--------------footer -------------->

    <footer id="banner">
        <p id="cookies">Accept cookies?</p>
        <div id="output"></div>
        <a id="link" href="#"></a>
    
    </footer> 
    
    <script src="main.js"></script>
     
</body>
</html>