<?php ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>home</title>
        <link rel="icon" type="image/x-icon" href="image/favicon.ico">
        <link rel="stylesheet" href="../style.css">
        <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
        
    </head>
<body>
    <header>
        <div class="container">
            <div class="main-header">
                
                <img class="logo" src="../image/logo.png" alt="Logo" style="width:60px;height:60px">
                <nav>
                    <ul>
                        <li><a href="../home.php">Home</a></li>
                        <li><a href="../about.php">About</a></li>
                        <li><a href="../contact-form.php">Contact</a></li>
                    </ul>
                </nav>
            </div>
        </div>  
    </header>     

    <div class="page">  
        <div class="content" id="technical">

            <div class="heading-category">
                <a href="articles/technical.html">Technical</a>
            </div>

            <article>
                <h1>International Student Recruitment and Retention is a Priority for Canada</h1>
                <img src="../image/The-Express-Entry-CRS-score-slips-to-496-in-an-All-Program-Draw-IMC.jpeg" alt="">
                
                <aside>
                <p>Author: Brown Black<p>
                <p>
                    Immigration Refugees and Citizenship Canada (IRCC) has responded to the Standing Committee on Citizenship and Immigration (CIMM) of the Canadian House of Commons on measures needed to attract, aid, and protect international students.
                </p>
                <p>
                    CIMM is a government body that evaluates matters of immigration and citizenship in Canada. The body oversights IRCC and screens the federal multiculturalism policy. The CIMM report was created to state the fact that while Canada is a global leader in inviting international students, few students will be placed in vulnerable situations due to various factors that can be addressed by IRCC.
                </p>
                    <h2>Recruiting International Students</h2>
                    <p>
                    Government officials acknowledged that the number of international students obtaining study permits is expected to increase from 2022 to 2023 to approximately 753,000; while acknowledging CIMM concerns that despite increases, the department does not give adequate consideration to applications from certain countries and populations.

                    In response, Immigration, Refugees, and Citizenship Canada devoted to:
                
                     Discover the development of the Student Direct Stream in specific Asian, African, and French-speaking countries. The SDS is a fast-track stream for attaining a study permit for applicants from 14 countries.
                     
                     Examine rates of the study permit refusals, intended for Quebec by establishing a working group between Ministère de l’Immigration, de la Francisation et de l’Intégration (MIFI) and IRCC.
                </p>
                <a href ="https://immigcanada.com/international-student-recruitment-and-retention-is-a-priority-for-canada/" target="_blank">Source</a>
                </aside>
            </article>

            <article>
                <h1>Can You Apply for Multiple Canadian Immigration Programs Together?</h1>
                <img src="../image/Can-you-Apply-for-Multiple-Canadian-Immigration-Programs-Together-CIN.jpeg" alt="">
                
                <aside>
                <p>Author: Dan Smith</p>
                <p>
                    Canada offers more than 100 economic class immigration programs to choose from, it is likely to qualify for more than one Canadian immigration program. Thus, it also raises the question of whether you can apply for more than one program at the same time or not. Possibly you can qualify for Express Entry, however, do not necessarily wish to cross your fingers for Invitation to Apply (ITA), as that base Provincial Nominee Program (PNP) looks more interesting- even if it’s a long process. The question is whether you can apply for both or not.
                </p>
                <p>
                    Immigration, Refugees, and Citizenship Canada (IRCC) suggest one may go ahead with two applications at once, however, they have to withdraw one before a decision can be made on the other and one must also know that they will not receive a refund on any processing fees paid. In a case, where the candidate has applied second application while an earlier application is in litigation, both of them will be processed through their respective processes until the final decision is made on one of the applications.
                </p>
                    <h2>One can have only one Express Entry Profile</h2>
                    <p>
                        Canadian immigration regulations do not permit one to have more than one profile at a time. The IRCC clearly states that having more than one profile will not offer a better chance of being shortlisted, nor permit one to be invited under another program. One may, include their common-law partner or spouse on their Express Entry application. Every application that goes through Express Entry has a principal applicant (PA), who is evaluated through the Comprehensive Ranking System and gets a score. The principal applicant (PA) is permitted to add the spouse and dependent children to the application.
                    </p>
                    <p>
                        While applying as a couple, only one of the partners can be the PA. The couple can select which partner can be the PA as long as both partners stand eligible for at least one Express Entry-managed program. This rule is essential as one of the partners will definitely have a higher CRS score than the other.
                    </p>
                </aside>
                <a href ="https://immigcanada.com/multiple-canadian-immigration-programs/" target="_blank">Source</a>
            </article>

    <a href="../home.html">Go back</a>

    <footer id="banner">
        <p id="cookies">Accept cookies?</p>
        <div id="output"></div>
        <a id="link" href="#"></a>
    
    </footer> 
    
    <script src="../main.js"></script>
    

</body>
</html>