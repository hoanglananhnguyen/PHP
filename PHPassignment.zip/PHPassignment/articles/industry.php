<?php ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>home</title>
        <link rel="icon" type="image/x-icon" href="image/favicon.ico">
        <link rel="stylesheet" href="../style.css">
        <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
        
    </head>
<body>
    <header>
        <div class="container">
            <div class="main-header">
                
                <img class="logo" src="../image/logo.png" alt="Logo" style="width:60px;height:60px">
                <nav>
                    <ul>
                        <li><a href="../home.php">Home</a></li>
                        <li><a href="../about.php">About</a></li>
                        <li><a href="../contact-form.php">Contact</a></li>
                    </ul>
                </nav>
            </div>
        </div>  
    </header>      


    <div class="page">  
        <div class="content" id="industry">

            <div class="heading-category">
                <a href="articles/industry.html">Industry</a>
            </div>
   
            <article>
                <h1>This Fiscal Year, IRCC Plans to Grant Citizenship to 300,000 People</h1>
                <img src="../image/This-Fiscal-Year-IRCC-Plans-to-Grant-Citizenship-to-300000-People-ImmigCanada.jpeg" alt="">
                
                <aside>
                <p>Author: Rosary</p>
                <p>
                    Canada is planning to offer citizenship to 300,000 immigrants in the year 2022-2023. A recent memo by IRCC outlines targets for the number of new citizens the country is planning to welcome in the fiscal year 2022-2023. The memo was drafted by the Operations, Planning, and Performance department of IRCC which recommends that it process a total of 285,000 decisions and 300,000 new citizens by March 31, 2023. Upon reviewing an application, a decision is made that either approves, denies, or marks the application as incomplete. A citizenship target means that 300,000 approved applicants must take the oath of citizenship.
                </p>
            
                    <h2>Applications will no longer be accepted on paper by IRCC</h2>
                    <p>
                        Due to the onset of Pandemic in the March 2020, IRCC became unable to process most applications. The department was only able to process paper applications which were mailed to a central location. As all in-person events were also canceled, this meant that IRCC was unable to organize interviews with applicants and there could not be any oath-swearing citizenship ceremonies.
                    </p>
                    <a href ="https://immigcanada.com/ircc-plans-to-grant-citizenship-to-300000-people/" target="_blank">Source</a>
                </aside>
            </article>

            <article>
                <h1>Canada Still has More Vacancies than Jobs</h1>
                <img src="../image/Canada-Still-has-More-Vacancies-than-Jobs-ImmigCanada.jpeg" alt="">
                    
                <aside>
                <p>Author: William</p>
                <p>
                    Recently, Canada’s employment rate has been falling, with many of their job vacancies not being filled. In addition, Canada’s monthly report on pay and employment has revealed that the number of employees receiving pay or benefits from their employer has decreased for the first time since last May. As a result, 26,000 jobs are no longer on the payroll of surveyed employers.
                
                </p>
                    <h2>Canada Still has Over One Million Job Vacancies.</h2>
                    <p>
                    There have been significant job losses to industries like educational services, healthcare, and social assistance due to the elimination of jobs in the construction sector. The loss of these jobs is largely attributed to a province-wide strike which caused significant delays on projects throughout construction.
                    </p>
                    <h2>Retail trade jobs are better than expected.</h2>
                    <p>
                    Despite the decrease in employment in Ontario’s retail trade industry, the overall current rate is still six percent higher than it was in May 2021. As well, one sector that showed growth in every province of Canada is professional, scientific, and technical services.
                    </p>
                <a href ="https://immigcanada.com/canada-job-vacancies/" target="_blank">Source</a>
                </aside>
            </article>

    <a href="../home.html">Go back</a>

    <footer id="banner">
        <p id="cookies">Accept cookies?</p>
        <div id="output"></div>
        <a id="link" href="#"></a>
    
    </footer> 
    
    <script src="../main.js"></script>

</body>
</html>