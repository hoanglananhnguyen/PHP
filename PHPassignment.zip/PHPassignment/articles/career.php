<?php ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>home</title>
        <link rel="icon" type="image/x-icon" href="image/favicon.ico">
        <link rel="stylesheet" href="../style.css">
        <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
        
    </head>
<body>
    <header>
        <div class="container">
            <div class="main-header">
                
                <img class="logo" src="../image/logo.png" alt="Logo" style="width:60px;height:60px">
                <nav>
                    <ul>
                        <li><a href="../home.php">Home</a></li>
                        <li><a href="../about.php">About</a></li>
                        <li><a href="../contact-form.php">Contact</a></li>
                    </ul>
                </nav>
            </div>
        </div>  
    </header>             

    <div class="page">
        <div class="content" id="career">

            <div class="heading-category">
                <a href="articles/career.html">Career</a>
            </div>

            <article>
                <h1>Canada Strengthens Protections for Temporary Foreign Workers</h1>
                <img src="../image/Canada-Strengthens-Protections-for-Temporary-Foreign-Workers-ImmigCanada.jpg" alt=""> 

            <aside>
            <p>Author: Peter Pan</p>
            <p>
                Employment and Social Development Canada (ESDC) with Immigration, Refugees and Citizenship Canada (IRCC) has announced reforms to the Immigration and Refugee Protection Regulations regarding Temporary Foreign Workers (TFWs). There are 13 reforms designed to support protections for TFWs and improve the Temporary Foreign Workers Program (TFWP).
            </p>
            <h3>Right of Temporary Foreign Workers</h3>
            <p>
                TFWs possess similar rights as Canadian citizens or permanent residents. This concludes that employers are legally obligated to offer a safe working atmosphere that is free from harassment and reprisals. Furthermore, if an employer refuses to pay overtime to an employee as stipulated in the employment agreement, it is illegal. Employees make sure to have a signed copy of this agreement before they first start the job.
            </p>
            <p>
                Immigration Minister Sean Fraser mentioned in a recent interview that “In Canada, the rights of all the workers including temporary foreign workers are protected by law. The international mobility program defines requirements and conditions for employing TFWs in Canada and offers open work permits to defenseless employees who are facing injustice in the work environment. With these new reforms in place, the federal government of Canada is strengthening its ability to safeguard temporary foreign workers and is advancing its capacity to avert potential mistreatment during TFWs period of employment in Canada.”
            </p>

            <a href="https://immigcanada.com/canada-strengthens-protections-for-temporary-foreign-workers/" target="_blank">Source</a>
            </aside>
   
            </article>
        
            <article>
                <h1>International Students Will Be Allowed to Work Off-Campus For More than 20 Hours A Week in Canada</h1>
                <img src="../image/International-Students-will-be-allowed-to-work-off-campus-for-more-than-20-hours-a-week-in-Canada-compressed.jpeg" alt="">
                
            <aside>
                <p>Author: Will Smith</p>
                <p>
                    Between November 15, 2022, and December 31, 2022, international students who are studying in Canada and have off-campus authorization on their study permit will be permitted to work 20 hours a week. This temporary reform will also permit foreign nationals who have already submitted a study permit application. They will be able to benefit from this policy if IRCC approves the application. Immigration Minister, Sean Fraser made an announcement about this policy and also mentioned that this measure targets to relieve the labour shortages in Canada.
                </p>
                <p>
                    Canada is currently struggling with labour shortages and an all-time low unemployment rate. Statistics Canada reported that Canada’s unemployment rate declined by 5.2% in September, and 5.4% in August. Currently, foreign students who wish to apply to study in a qualifying Canadian educational program will be accredited to work off-campus during their course for up to 20 hours a week.
                </p>
                <p>
                    This restriction will be lifted during organized breaks such as the summer and winter breaks. This reform will also permit foreign students to support themselves financially while ensuring to focus on completing their studies rather than concentrating on working in Canada. Due to the major labour shortages in the country, the Federal government of Canada has been easing this rule for the time being.
                </p>
    
                <a href="https://immigcanada.com/international-students-will-be-allowed-to-work-off-campus/" target="_blank">Source</a>
            </aside>         
            </article>

</div>
</div>

    <a href="../home.html">Go back</a>

    <footer id="banner">
        <p id="cookies">Accept cookies?</p>
        <div id="output"></div>
        <a id="link" href="#"></a>
    
    </footer> 
    
    <script src="../main.js"></script>
     
</body>
</html>