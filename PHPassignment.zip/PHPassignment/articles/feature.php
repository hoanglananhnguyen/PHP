<?php ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>home</title>
        <link rel="icon" type="image/x-icon" href="image/favicon.ico">
        <link rel="stylesheet" href="../style.css">
        <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
        
    </head>
<body>

    <header>
        <div class="container">
            <div class="main-header">
                
                <img class="logo" src="../image/logo.png" alt="Logo" style="width:60px;height:60px">
                <nav>
                    <ul>
                        <li><a href="../home.html">Home</a></li>
                        <li><a href="../about.html">About</a></li>
                        <li><a href="../contact.html">Contact</a></li>
                    </ul>
                </nav>
            </div>
        </div>  
    </header>       

    <div class="page">
        <div class="content" id="featured">

            <div class="heading-category">
                <a href="articles/feature.html">Featured</a>
            </div>
            
            <article>
                <h1>The Top Trending Jobs in Canada 2022</h1>
                <img src="../image/The-Top-Trending-Jobs-in-Canada-2022-compressed.jpeg" alt="">

            <aside>
            <p>Author: Stephany</p>
            <p>
                The Canadian economy is doing well right now, thanks partly to a strong housing and robust job market. 2022 is when the Canadian Labour Market Outlook report predicts that some of the most in-demand jobs are being available and trending in Canada. In this blog, we’ll look at some of the jobs expected to be in demand in Canada in 2022.
            </p>

            <h2>Logistics Manager</h2> 

            <p>
                Logistics managers are in high demand in Canada as it continues to grow and develop its economy. This is due to the increasing demand for goods and services and an increase in population. Some of the most common jobs that a logistics manager will be responsible for include organizing and managing supplies and materials, ensuring that products are delivered on time, and issuing reports on inventory levels. In addition, a logistics manager will often be involved in developing new shipping methods or improving existing ones.
            </p>

            <h2>Developer</h2>
            <p>
                One of the most popular jobs in demand in Canada in the next few years is a developer. Developers work on creating new software, websites, and applications. They use their creative minds to develop new ways to make things easier or more fun for people. To become a developer, you need to have a degree in computer science or a related field. You will also need to have experience programming and working with computers. Finally, you will need to be able to work well under pressure and be able to stay organized.
            </p>
            <a href="https://immigcanada.com/top-trending-jobs-in-canada-2022/" target="_blank">Source</a>
        </aside>
        
    </article>

    <a href="../home.html">Go back</a>

    <footer id="banner">
        <p id="cookies">Accept cookies?</p>
        <div id="output"></div>
        <a id="link" href="#"></a>
    
    </footer> 
    
    <script src="main.js"></script>

</body>
</html>