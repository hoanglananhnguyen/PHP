<?php ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>home</title>
        <link rel="icon" type="image/x-icon" href="image/favicon.ico">
        <link rel="stylesheet" href="style.css">
        <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
        
    </head>
	<body>
	
<?php

session_start();
	//process-signup.php

	//receive form variables
	$username = $_POST["username"];
	$password = $_POST["password"];
	$email = $_POST["email"];
	
	
	//connect
	$dsn = "mysql:host=localhost;dbname=singhwa_imm2023;charset=utf8mb4";
	$dbusername = "root";
	$dbpassword = "root";

	$pdo = new PDO($dsn, $dbusername, $dbpassword);

	//prepare

	$stmt = $pdo->prepare("INSERT INTO `User` 
	(`userId`, `username`, `email`, `password`, `role`)
	VALUES (NULL, '$username', '$email', '$password', '');");

	if($stmt->execute() == true){
		?><p>Congratulations<p><?php
	}else{
		?> <p>Please try again<p><?php
	}
?>
<a href="login-form.php">Log in</a>
	
</body>
	</html>
