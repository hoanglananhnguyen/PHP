
<?php ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home</title>
    <link rel="icon" type="image/x-icon" href="image/favicon.ico">
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    
</head>
<body>

<!--------------header -------------->
<header>
        <div class="container">
            <div class="main-header">
                
                <img class="logo" src="image/logo.png" alt="Logo" style="width:60px;height:60px">
                <nav>
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Contact</a></li>
                    </ul>
                </nav>
            </div>
        </div>  
    </header>   

<!--------------form -------------->
<div class="content">
     <h1>Sign up</h1>
     <form action="process-signup.php" method="POST"> 
     Username: <input type="text" name="username" /><br>
     Email: <input type="text" name="email" /><br>
     Password: <input type="text" name="password" /><br>

     
     <input type="submit" />   
     </form>
</div>     
</body>
</html>
