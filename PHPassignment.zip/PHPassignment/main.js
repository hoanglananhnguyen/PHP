//main.js
console.log("connected")

//visitors

let visitors = [
  { month: "June",
    visitorNumber: 50

  },
  { month: "July",
    visitorNumber: 35

  },
  { month: "August",
  visitorNumber: 40

  },
  { month: "September",
  visitorNumber: 67

  },
  { month: "October",
  visitorNumber: 84

  },
  { month: "November",
  visitorNumber: 90

  }]

  console.log(visitors);
  
  let table = document.createElement("table");
  
  for (let i=0; i<6; i++){
    let tr = document.createElement("tr");
    table.appendChild(tr);

    let td = document.createElement("td");
    let td2 = document.createElement("td");
    tr.appendChild(td);
    tr.appendChild(td2);

    let month = document.createTextNode(visitors[i].month)
    let visitor = document.createTextNode(visitors[i].visitorNumber)
    td.appendChild(month);
    td2.appendChild(visitor);
  }

  console.log(table);
  // document.getElementById(main).appendChild(table); //need connect table to existing element
  document.body.appendChild(table); //need connect table to existing element

//cookies
  let banner = document.getElementById("banner");
  let output = document.getElementById("output");
  let cookies = document.getElementById("cookies");
  let link = document.getElementById("link");
  
  cookies.addEventListener('click', handlerFunction);
  function handlerFunction(event){
    cookies.remove();
    // create new p
    let newP = document.createElement("p");
    // create new content
    let accepted = document.createTextNode("Cookies were accepted. Would you like to revoke?");

    newP.appendChild(accepted); //<p>new content</p>
 
  //add an eventlistener on to newP
    newP.addEventListener('click', handlerFunction);

  //create a event handler for this event
  // in eventhandler remove this paragraph and create a para "accept cookies?"
    function handlerFunction(event){
      newP.remove();
      let newPP = document.createElement("p");
      let revoke = document.createTextNode("Accepted cookies?");
      newPP.appendChild(revoke);
      output.appendChild(newPP);
    }
    output.appendChild(newP);
  };
  
  
// dark mode
  function toggleHighContrast() {
    var element = document.body;
    element.classList.toggle("dark-mode");
  }

  function registerKeyEvents() {
    document.addEventListener('keydown', (event) => {
      var name = event.key;
      var code = event.code;
      if (name === 'Control') {
        // Do nothing.
        return;
      }
      
      if (event.ctrlKey) {
        if (code == "KeyA") {
          event.preventDefault();
          toggleHighContrast();
        }
      }
    }, false);
  }